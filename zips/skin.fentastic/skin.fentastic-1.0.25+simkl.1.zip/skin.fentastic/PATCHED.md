# Patched build

FENtastic by **Ivar Brandt**, GPL-2.0 / CC BY-SA 4.0. Unmodified except:

- search provider 3 repointed from `plugin.video.pov` to `plugin.video.pov.simkl`
- the "TRAKT Lists" search widget hidden for that provider, since SIMKL
  has no community lists for it to query

Regenerate with `tools/patch_fentastic.py` after any upstream update.
