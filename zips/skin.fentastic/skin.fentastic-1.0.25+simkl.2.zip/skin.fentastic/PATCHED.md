# Patched build

FENtastic by **Ivar Brandt**, GPL-2.0 / CC BY-SA 4.0. Unmodified except:

- search provider 3 repointed from `plugin.video.pov` to `plugin.video.pov.simkl`
- the "TRAKT Lists" search widget hidden for that provider, since SIMKL
  has no community lists for it to query
- people search repointed from `get_search_term` to `person_search`.
  get_search_term ends in a Container.Update, and FENtastic loads it as a
  widget content path, so the widget navigated the window that owns it --
  unbounded re-entrancy that crashed Kodi on tvOS. Predates the fork.

Regenerate with `tools/patch_fentastic.py` after any upstream update.

## After installing

Skin settings > Main menu items > **Remake menus and widgets**.

FENtastic generates its menu/widget XMLs into the skin directory, and Kodi
replaces that directory on every update, so they need regenerating. Your
configuration is safe -- it lives in `userdata/addon_data/skin.fentastic/`.
This applies to any FENtastic update, not just this patched build.
