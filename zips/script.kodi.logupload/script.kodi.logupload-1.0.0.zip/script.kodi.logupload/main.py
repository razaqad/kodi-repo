"""Upload the Kodi log to paste.kodi.tv and show the link.

Deliberately dependency-free. The log is wanted precisely when something is
broken, and an uploader that needs script.module.requests cannot run on the
profile where that dependency failed to install -- which on tvOS is every
profile after the OS clears Library/Caches.
"""

import json
import platform
import re
import urllib.error
import urllib.request

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON = xbmcaddon.Addon()
NAME = ADDON.getAddonInfo('name')

PASTE_URL = 'https://paste.kodi.tv/'
# haste-server rejects documents past ~400KB. Stay under it with room for the
# header we prepend.
MAX_BYTES = 380000
CURRENT_LOG = 'special://logpath/kodi.log'
PREVIOUS_LOG = 'special://logpath/kodi.old.log'

# A window property makes the URL readable over JSON-RPC, so the link can be
# collected without anyone reading it off the screen and retyping it.
URL_PROPERTY = 'kodi_log_upload_url'

# Matched against the log before upload. Ordered most specific first: the
# Authorization rule has to win before the generic `auth=` rule reaches it.
REDACTIONS = (
    # Quotes may sit on either side of the separator -- logs print this both as
    # a raw header and as a dict repr: 'Authorization': 'Bearer <token>'.
    (re.compile(r'(Authorization["\']?\s*[:=]\s*["\']?(?:Bearer|Basic|token)\s+)'
                r'([^\s"\'<>,;)\]}]+)', re.I),
     r'\1<redacted>'),
    (re.compile(r'((?:access[_-]?token|refresh[_-]?token|api[_-]?key|apikey|'
                r'client[_-]?secret|secret|token|password|passwd|pwd|auth|'
                r'session[_-]?id)["\']?\s*[=:]\s*["\']?)([^\s&"\'<>,;)\]}]+)', re.I),
     r'\1<redacted>'),
    # user:pass@host in a URL
    (re.compile(r'(://)([^/\s:@]+):([^/\s@]+)@'),
     r'\1<redacted>:<redacted>@'),
)


def redact(text):
    for pattern, replacement in REDACTIONS:
        text = pattern.sub(replacement, text)
    return text


def read_log(path):
    if not xbmcvfs.exists(path):
        return None
    handle = xbmcvfs.File(path)
    try:
        return handle.readBytes().decode('utf-8', 'replace')
    finally:
        handle.close()


def build_document(text, scrub):
    notes = []
    if scrub:
        text = redact(text)
        notes.append('credentials redacted')
    else:
        notes.append('NOT redacted -- may contain tokens and passwords')

    encoded = text.encode('utf-8')
    if len(encoded) > MAX_BYTES:
        # Keep the end. Whatever went wrong is at the bottom of the log, and a
        # truncated head would silently look like a complete file.
        text = encoded[-MAX_BYTES:].decode('utf-8', 'replace')
        cut = text.find('\n')
        if cut != -1:
            text = text[cut + 1:]
        notes.append('trimmed to the last %d KB' % (MAX_BYTES // 1024))

    header = '%s | Python %s | %s\n%s\n' % (
        xbmc.getInfoLabel('System.BuildVersion'),
        platform.python_version(),
        ', '.join(notes),
        '-' * 60,
    )
    return header + text


def upload(document):
    request = urllib.request.Request(
        PASTE_URL + 'documents',
        data=document.encode('utf-8'),
        headers={'Content-Type': 'text/plain; charset=utf-8',
                 'User-Agent': 'KodiLogUploader/%s' % ADDON.getAddonInfo('version')},
    )
    with urllib.request.urlopen(request, timeout=30) as response:
        payload = json.loads(response.read().decode('utf-8'))
    key = payload.get('key')
    if not key:
        raise ValueError('paste service returned no key')
    return PASTE_URL + key


def choose():
    """Returns (path, scrub) or None if the user backed out."""
    options = [('Upload kodi.log', CURRENT_LOG, True)]
    if xbmcvfs.exists(PREVIOUS_LOG):
        options.append(('Upload kodi.old.log (previous run)', PREVIOUS_LOG, True))
    options.append(('Upload kodi.log without redaction', CURRENT_LOG, False))

    index = xbmcgui.Dialog().select(NAME, [label for label, _, _ in options])
    if index < 0:
        return None
    _, path, scrub = options[index]

    if not scrub and not xbmcgui.Dialog().yesno(
            NAME,
            'This uploads the log with tokens and passwords left in, to a public '
            'paste anyone with the link can read.\n\nUpload it unredacted?',
            nolabel='Cancel', yeslabel='Upload raw'):
        return None
    return path, scrub


def main():
    selection = choose()
    if selection is None:
        return
    path, scrub = selection

    text = read_log(path)
    if text is None:
        xbmcgui.Dialog().ok(NAME, 'No log found at:\n%s' % path)
        return

    progress = xbmcgui.DialogProgressBG()
    progress.create(NAME, 'Uploading log...')
    try:
        url = upload(build_document(text, scrub))
    except urllib.error.HTTPError as error:
        xbmcgui.Dialog().ok(NAME, 'Upload rejected by the paste service.\n'
                                  'HTTP %s' % error.code)
        return
    except Exception as error:  # noqa: BLE001 -- surface anything to the user
        xbmc.log('%s: upload failed: %s' % (NAME, error), xbmc.LOGERROR)
        xbmcgui.Dialog().ok(NAME, 'Upload failed.\n\n%s' % error)
        return
    finally:
        progress.close()

    xbmcgui.Window(10000).setProperty(URL_PROPERTY, url)
    xbmc.log('%s: %s' % (NAME, url), xbmc.LOGINFO)
    xbmcgui.Dialog().ok(NAME, url)


if __name__ == '__main__':
    main()
