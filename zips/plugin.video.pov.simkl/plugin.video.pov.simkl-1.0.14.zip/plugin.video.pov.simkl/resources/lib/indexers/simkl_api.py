import requests
from threading import Thread
from concurrent.futures import ThreadPoolExecutor
from caches import simkl_cache
from caches.main_cache import cache_object
from indexers.tmdb_api import movie_external_id, tvshow_external_id
from modules import kodi_utils, settings
from modules.cache import check_databases
from modules.utils import sort_for_article, jsondate_to_datetime, paginate_list, get_datetime, TaskPool

ls, logger = kodi_utils.local_string, kodi_utils.logger
get_setting, set_setting = kodi_utils.get_setting, kodi_utils.set_setting
EXPIRES_2_DAYS = 48
CLIENT_ID = kodi_utils.addon().getSetting('simkl.client_id')
base_url = 'https://api.simkl.com/%s'
timeout = 10.05
# SIMKL ignores `limit` on the discovery endpoints and always answers with 50.
TRENDING_PAGE_SIZE = 50
session = requests.Session()
session.headers.update({'User-Agent': kodi_utils.xbmc.getUserAgent()})
retry = requests.adapters.Retry(total=None, status=1, status_forcelist=(429, 502, 503, 504))
session.mount('https://api.simkl.com', requests.adapters.HTTPAdapter(pool_maxsize=100, max_retries=retry))

def call_simkl(path, params=None, data=None, with_auth=True, method=None, pagination=False, page=1):
	if isinstance(path, dict): return call_simkl(str(path.pop('path')), **path)
	else: path = str(path)
	headers = {'Content-Type': 'application/json', 'simkl-api-key': CLIENT_ID}
	if with_auth and (token := get_setting('simkl.token')): headers['Authorization'] = 'Bearer %s' % token
	try:
		response = session.request(
			'post' if data is not None else method or 'get',
			base_url % path,
			params=None if data is not None else params,
			json=data if data else None,
			headers=headers,
			timeout=timeout
		)
		result = response.json() if 'json' in response.headers.get('Content-Type', '') else response.text
		if not response.ok: response.raise_for_status()
		if pagination:
			# SIMKL sends no page-count header. A full page implies there may be
			# another; a short page means we have reached the end.
			total_pages = page + 1 if isinstance(result, list) and len(result) >= TRENDING_PAGE_SIZE else page
			return result, total_pages
		return result
	except requests.RequestException as e:
		logger('simkl error', str(e))

###############################################################################
# ID resolution
#
# Discovery endpoints (trending, airing) return only simkl_id, but POV is
# TMDb-keyed throughout. The detail endpoint carries the full id set, so resolve
# through it and cache permanently -- a simkl_id -> tmdb_id mapping never changes.
#
# The sync endpoints do NOT need this: /sync/all-items/* already returns tmdb.
###############################################################################

def _simkl_detail_ids(simkl_id, media_type):
	path = 'movies/%s' % simkl_id if media_type == 'movie' else 'tv/%s' % simkl_id
	result = call_simkl(path, params={'extended': 'full'}, with_auth=False)
	if not isinstance(result, dict): return None
	return result.get('ids') or {}

def _resolve_one(simkl_id, media_type):
	if not simkl_id: return None
	if (cached := simkl_cache.get_id_map(simkl_id, media_type)): return cached
	ids = _simkl_detail_ids(simkl_id, media_type)
	if not ids: return None
	tmdb_id = ids.get('tmdb')
	if not tmdb_id:
		# Fall back through TMDb's own external-id lookup, as trakt_api did.
		external = (('imdb_id', 'imdb'), ('tvdb_id', 'tvdb'))
		finder = movie_external_id if media_type == 'movie' else tvshow_external_id
		for source, key in external:
			if not ids.get(key): continue
			try:
				found = finder(source, ids[key])
				if found:
					tmdb_id = found['id']
					break
			except: pass
	if not tmdb_id: return None
	simkl_cache.set_id_map(simkl_id, media_type, tmdb_id)
	return str(tmdb_id)

def get_simkl_movie_id(simkl_id):
	return _resolve_one(simkl_id, 'movie')

def get_simkl_tvshow_id(simkl_id):
	return _resolve_one(simkl_id, 'tvshow')

def _resolve_bulk(simkl_ids, media_type):
	"""Resolve in parallel, preserving order. Unresolvable entries drop out."""
	if not simkl_ids: return []
	resolved = {}
	def _work(simkl_id):
		tmdb_id = _resolve_one(simkl_id, media_type)
		if tmdb_id: resolved[simkl_id] = tmdb_id
	args = [(i,) for i in simkl_ids]
	for i in TaskPool().tasks(_work, args, Thread): i.join()
	return [(i, resolved[i]) for i in simkl_ids if i in resolved]

def _discovery_items(result, media_type):
	"""Turn a raw discovery payload into POV's id-dict list shape."""
	if not isinstance(result, list): return []
	key = 'movie' if media_type == 'movie' else 'show'
	simkl_ids, ratings = [], {}
	for item in result:
		ids = item.get('ids') or {}
		simkl_id = ids.get('simkl_id') or ids.get('simkl')
		if not simkl_id: continue
		simkl_ids.append(simkl_id)
		try: ratings[simkl_id] = item['ratings']['simkl']['rating']
		except: pass
	return [
		{key: {'ids': {'tmdb': tmdb_id, 'simkl': simkl_id, 'simkl_rating': ratings.get(simkl_id)}}}
		for simkl_id, tmdb_id in _resolve_bulk(simkl_ids, media_type)
	]

def _trending(path, media_type, page_no, string):
	params = {'page': page_no}
	url = {'path': path, 'params': params, 'with_auth': False, 'pagination': True}
	cached = cache_object(call_simkl, string, url, expiration=EXPIRES_2_DAYS)
	try: result, total_pages = cached
	except: return [], page_no
	return _discovery_items(result, media_type), total_pages

###############################################################################
# Discovery menus
###############################################################################

def simkl_movies_trending(page_no):
	return _trending('movies/trending/week', 'movie', page_no, 'simkl_movies_trending_%s' % page_no)

def simkl_movies_most_watched(page_no):
	return _trending('movies/trending/month', 'movie', page_no, 'simkl_movies_most_watched_%s' % page_no)

def simkl_tv_trending(page_no):
	return _trending('tv/trending/week', 'tvshow', page_no, 'simkl_tv_trending_%s' % page_no)

def simkl_tv_most_watched(page_no):
	return _trending('tv/trending/month', 'tvshow', page_no, 'simkl_tv_most_watched_%s' % page_no)

###############################################################################
# Personal lists
#
# SIMKL has five fixed statuses and no user-created lists:
#   watching | plantowatch | completed | hold | dropped
###############################################################################

def _media_path(mediatype):
	return 'movies' if mediatype in ('movie', 'movies') else 'shows'

def _media_key(mediatype):
	return 'movies' if mediatype in ('movie', 'movies') else 'shows'

def _item_key(mediatype):
	return 'movie' if mediatype in ('movie', 'movies') else 'show'

def _sync_list(mediatype, status):
	"""Fetch a status list. These carry full ids, so no resolution is needed."""
	path = 'sync/all-items/%s/%s' % (_media_path(mediatype), status)
	result = call_simkl(path, params={'extended': 'full'})
	if not isinstance(result, dict): return []
	return result.get(_media_key(mediatype)) or []

def _to_media_ids(items, mediatype):
	item_key = _item_key(mediatype)
	out = []
	for i in items:
		try:
			ids = i[item_key]['ids']
			if not ids.get('tmdb'): continue
			out.append({
				'media_ids': {'tmdb': str(ids['tmdb']), 'imdb': ids.get('imdb'), 'tvdb': ids.get('tvdb')},
				'title': i[item_key].get('title', ''),
				'added_at': i.get('added_to_watchlist_at') or i.get('last_watched_at') or ''
			})
		except: pass
	return out

def _status_list(mediatype, status):
	"""A status list as media-id dicts, cached under the one canonical key."""
	def _process(_):
		return _to_media_ids(_sync_list(mediatype, status), mediatype)
	return simkl_cache.cache_simkl_object(
		_process, simkl_cache.status_list_key(status, mediatype), None) or []

def _paginated_status_list(mediatype, status, page_no):
	data = _status_list(mediatype, status)
	if get_setting('simkl.reverse') == 'true': data = list(reversed(data))
	return paginate_list(data, page_no, settings.page_limit())

def simkl_watchlist(mediatype, page_no):
	return _paginated_status_list(mediatype, 'plantowatch', page_no)

def simkl_watching(mediatype, page_no):
	return _paginated_status_list(mediatype, 'watching', page_no)

def simkl_completed(mediatype, page_no):
	return _paginated_status_list(mediatype, 'completed', page_no)

def simkl_droplist(mediatype, page_no):
	return _paginated_status_list(mediatype, 'dropped', page_no)

def simkl_hold(mediatype, page_no):
	return _paginated_status_list(mediatype, 'hold', page_no)

def simkl_fetch_collection_watchlist(list_type, mediatype):
	"""Used to test membership from the context menu.

	Shares its cache entry with the menu that lists the same status, so the two
	can never disagree about what is on a list.
	"""
	return _status_list(mediatype, list_type)

def simkl_watchlist_tmdb_ids(mediatype):
	"""TMDb ids currently in plantowatch, as a set.

	Called once per menu build so the context menu can say Add or Remove rather
	than offering a blind toggle. The underlying fetch is cached, so this costs
	one SIMKL call per cache miss and a set lookup per item. Returns an empty
	set on failure -- a menu that says "Add" wrongly is better than no menu.
	"""
	try:
		items = simkl_fetch_collection_watchlist('plantowatch', mediatype)
		return {str(i['media_ids']['tmdb']) for i in items if i.get('media_ids', {}).get('tmdb')}
	except Exception:
		return set()

def simkl_watchlist_toggle(mediatype, media_id):
	"""Add to or remove from plantowatch, whichever the item is not.

	The decision is made against a freshly fetched list, never the cache. Getting
	it wrong does the exact opposite of what was asked, and does it silently --
	both calls return 200, so nothing surfaces in the UI or the log. One extra
	GET on an explicit button press is a fair price for that.
	"""
	simkl_cache.clear_simkl_collection_watchlist_data('plantowatch', mediatype)
	current = simkl_watchlist_tmdb_ids(mediatype)
	in_list = str(media_id) in current
	logger('simkl watchlist toggle', '%s %s: list=%s(%d) member=%s -> %s' % (
		mediatype, media_id, type(current).__name__, len(current), in_list,
		'remove' if in_list else 'add'))
	if in_list:
		success = simkl_remove_from_list(mediatype, media_id)
	else:
		success = simkl_add_to_list('plantowatch', mediatype, media_id)
	if not success: return kodi_utils.notification(32574)
	simkl_cache.clear_simkl_collection_watchlist_data('plantowatch', mediatype)
	kodi_utils.container_refresh()
	return success

def simkl_get_hidden_items(list_type='dropped'):
	"""Shows hidden from continue-watching surfaces.

	Upstream POV read Trakt's users/hidden/dropped. SIMKL has no hidden-items
	endpoint, but its server-side `dropped` status means the same thing and --
	unlike a local table -- survives the Apple TV wiping addon storage.
	Returns a set of TMDb ids, matching trakt_get_hidden_items' contract.
	"""
	def _process(_):
		out = []
		for item in _sync_list('shows', 'dropped'):
			try:
				tmdb_id = item['show']['ids'].get('tmdb')
				if tmdb_id: out.append(int(tmdb_id))
			except: pass
		return out
	return set(simkl_cache.cache_simkl_object(_process, 'simkl_hidden_items_%s' % list_type, None) or [])

def hide_unhide_simkl_items(action, mediatype, media_id, list_type='dropped'):
	if action not in ('hide', 'unhide'):
		try:
			hidden_data = simkl_get_hidden_items(list_type)
			action = 'unhide' if int(media_id) in hidden_data else 'hide'
		except: return kodi_utils.notification(32574)
	if action == 'hide': success = simkl_add_to_list('dropped', mediatype, media_id)
	else: success = simkl_add_to_list('plantowatch', mediatype, media_id)
	simkl_cache.clear_simkl_list_data('hidden_items_%s' % list_type)
	# The item just moved between two status lists; both cached views are now wrong.
	simkl_cache.clear_simkl_collection_watchlist_data('dropped', mediatype)
	simkl_cache.clear_simkl_collection_watchlist_data('plantowatch', mediatype)
	kodi_utils.container_refresh()
	return success

def simkl_recommendations(mediatype):
	path = 'recommendations/%s' % _media_path(mediatype)
	def _process(_):
		result = call_simkl(path)
		if not isinstance(result, list): return []
		return _discovery_items(result, 'movie' if mediatype in ('movie', 'movies') else 'tvshow')
	string = 'simkl_recommendations_%s' % _media_path(mediatype)
	data = simkl_cache.cache_simkl_object(_process, string, None)
	item_key = _item_key(mediatype)
	return [{'media_ids': i[item_key]['ids']} for i in data]

###############################################################################
# Writes
###############################################################################

def _write_payload(media, media_id, tvdb_id=0, season=None, episode=None):
	entry = {'ids': {'tmdb': str(media_id)}}
	if season is not None and episode is not None:
		entry['seasons'] = [{'number': int(season), 'episodes': [{'number': int(episode)}]}]
	elif season is not None:
		entry['seasons'] = [{'number': int(season)}]
	return entry

def simkl_watched_unwatched(action, media, media_id, tvdb_id=0, season=None, episode=None, key='tmdb'):
	url = 'sync/history' if action == 'mark_as_watched' else 'sync/history/remove'
	mediatype = 'movies' if media in ('movie', 'movies') else 'shows'
	entry = _write_payload(media, media_id, tvdb_id, season, episode)
	data = {mediatype: [entry]}
	result = call_simkl(url, data=data)
	if result is None:
		# Offline or SIMKL is down. Keep the local change and replay on reconnect
		# rather than failing the user's action outright.
		simkl_cache.queue_pending_write('history', action, media, media_id, season, episode)
		logger('simkl', 'queued offline write: %s %s %s' % (action, media, media_id))
		return True
	simkl_sync_activities_thread()
	return True

def _flush_pending_writes():
	"""Replay writes that were queued while SIMKL was unreachable."""
	pending = simkl_cache.get_pending_writes()
	if not pending: return
	for row in pending:
		kind, action, mediatype, media_id, season, episode = row
		try:
			if kind == 'history':
				url = 'sync/history' if action == 'mark_as_watched' else 'sync/history/remove'
				key = 'movies' if mediatype in ('movie', 'movies') else 'shows'
				entry = _write_payload(mediatype, media_id, 0, season or None, episode or None)
				if call_simkl(url, data={key: [entry]}) is None: continue
			elif kind == 'list':
				if not simkl_add_to_list(action, mediatype, media_id): continue
			simkl_cache.clear_pending_write(row)
		except Exception as e:
			logger('simkl flush error', str(e))
	logger('simkl', 'flushed %d queued write(s)' % len(pending))

def simkl_add_to_list(status, mediatype, media_id):
	"""status: watching | plantowatch | completed | hold | dropped"""
	key = 'movies' if mediatype in ('movie', 'movies') else 'shows'
	data = {key: [{'ids': {'tmdb': str(media_id)}, 'to': status}]}
	result = call_simkl('sync/add-to-list', data=data)
	if result is None: return False
	simkl_sync_activities_thread()
	return True

def simkl_remove_from_list(mediatype, media_id):
	key = 'movies' if mediatype in ('movie', 'movies') else 'shows'
	data = {key: [{'ids': {'tmdb': str(media_id)}}]}
	result = call_simkl('sync/history/remove', data=data)
	if result is None: return False
	simkl_sync_activities_thread()
	return True

def simkl_rate(mediatype, media_id, rating):
	key = 'movies' if mediatype in ('movie', 'movies') else 'shows'
	data = {key: [{'ids': {'tmdb': str(media_id)}, 'rating': int(rating)}]}
	return call_simkl('sync/ratings', data=data) is not None

###############################################################################
# Watched indicators -- populate the local watched_status table
###############################################################################

def simkl_indicators_movies():
	insert_list = []
	insert_append = insert_list.append
	for item in _sync_list('movies', 'completed'):
		try:
			ids = item['movie']['ids']
			tmdb_id = ids.get('tmdb')
			if not tmdb_id: continue
			insert_append(('movie', str(tmdb_id), '', '', item.get('last_watched_at') or '', item['movie'].get('title', '')))
		except: pass
	simkl_cache.SimklCache().set_bulk_movie_watched(insert_list)

def _show_episode_numbers(simkl_id):
	"""Every (season, episode) a show has, from SIMKL's own episode listing.

	Cached without expiry -- the episode list of a finished show does not change,
	and this is only ever asked about completed shows.
	"""
	def _process(_):
		result = call_simkl('tv/episodes/%s' % simkl_id)
		if not isinstance(result, list): return []
		out = []
		for e in result:
			season_no, episode_no = e.get('season'), e.get('episode')
			if season_no is None or episode_no is None or season_no < 1: continue
			out.append((season_no, episode_no))
		return out
	return simkl_cache.cache_simkl_object(_process, 'simkl_eplist_%s' % simkl_id, None)

def _completed_show_episodes():
	"""Episode rows for shows marked completed on SIMKL.

	sync/all-items omits seasons[]/episodes[] for completed shows -- 'completed'
	implies all of them, so SIMKL enumerates none. Without this every fully
	watched show reads as 0 watched.

	Keyed off the completed STATUS, never off "seasons is empty": a show added
	but never started also has no seasons, and marking those fully watched would
	be badly wrong.
	"""
	rows = []
	result = call_simkl('sync/all-items/shows/completed', params={'extended': 'full'})
	shows = (result or {}).get('shows') or [] if isinstance(result, dict) else []
	targets = []
	for item in shows:
		try:
			show = item['show']
			ids = show['ids']
			tmdb_id, simkl_id = ids.get('tmdb'), ids.get('simkl') or ids.get('simkl_id')
			if not tmdb_id or not simkl_id: continue
			targets.append((str(simkl_id), str(tmdb_id), show.get('title', ''), item.get('last_watched_at') or ''))
		except: pass
	if not targets: return rows
	found = {}
	def _work(simkl_id):
		try: found[simkl_id] = _show_episode_numbers(simkl_id)
		except: found[simkl_id] = []
	for i in TaskPool().tasks(_work, [(t[0],) for t in targets], Thread): i.join()
	for simkl_id, tmdb_id, title, last_watched in targets:
		for season_no, episode_no in found.get(simkl_id) or []:
			rows.append(('episode', tmdb_id, season_no, episode_no, last_watched, title))
	return rows

def simkl_indicators_tv():
	insert_list = []
	insert_append = insert_list.append
	# Partially watched shows: sync/all-items carries their episode detail.
	result = call_simkl('sync/all-items/shows', params={'extended': 'full'})
	shows = (result or {}).get('shows') or [] if isinstance(result, dict) else []
	for item in shows:
		try:
			show = item['show']
			tmdb_id = show['ids'].get('tmdb')
			if not tmdb_id: continue
			title, last_watched = show.get('title', ''), item.get('last_watched_at') or ''
			for s in item.get('seasons') or []:
				season_no = s.get('number')
				if season_no is None or season_no < 1: continue
				for e in s.get('episodes') or []:
					episode_no = e.get('number')
					if episode_no is None: continue
					insert_append(('episode', str(tmdb_id), season_no, episode_no, last_watched, title))
		except: pass
	# Completed shows: episode detail has to be fetched per show.
	try: insert_list.extend(_completed_show_episodes())
	except: pass
	simkl_cache.SimklCache().set_bulk_tvshow_watched(insert_list)

###############################################################################
# Playback progress
###############################################################################

def simkl_progress(action, media, media_id, percent, season=None, episode=None, resume_id=None, refresh_simkl=False):
	"""No-op. Kept so callers mirroring trakt_progress' signature stay unchanged.

	SIMKL has no working playback-position API: /sync/playback answers GET with
	an empty list and stores nothing, and sync/activities reports playback as
	null. Verified against a live account. Resume points are therefore kept
	locally by watched_cache.set_bookmark, which also means resume survives
	offline and the Apple TV clearing add-on storage.

	The practical loss versus Trakt is cross-device resume -- a resume point set
	here stays on this device.
	"""
	return

def simkl_playback_progress():
	# See simkl_progress: SIMKL stores no playback positions.
	return []

def _progress_rows(progress_info, wanted_type):
	rows = []
	for item in progress_info or []:
		try:
			if item.get('type') != wanted_type: continue
			progress = float(item.get('progress') or 0)
			if progress <= 1: continue
			if wanted_type == 'movie':
				ids = item['movie']['ids']
				title = item['movie'].get('title', '')
				season, episode = '', ''
			else:
				ids = item['show']['ids']
				title = item['show'].get('title', '')
				season, episode = item['episode']['season'], item['episode']['number']
				if season < 1: continue
			tmdb_id = ids.get('tmdb')
			if not tmdb_id: continue
			rows.append((
				'movie' if wanted_type == 'movie' else 'episode', str(tmdb_id), season, episode,
				str(round(progress, 1)), 0, item.get('paused_at', ''), item.get('id', ''), title
			))
		except: pass
	return rows

def simkl_progress_movies(progress_info):
	simkl_cache.SimklCache().set_bulk_movie_progress(_progress_rows(progress_info, 'movie'))

def simkl_progress_tv(progress_info):
	simkl_cache.SimklCache().set_bulk_tvshow_progress(_progress_rows(progress_info, 'episode'))

def simkl_official_status(mediatype):
	return None

###############################################################################
# Sync service
###############################################################################

def simkl_get_activity():
	return call_simkl('sync/activities')

def simkl_sync_activities_thread(*args, **kwargs):
	Thread(target=simkl_sync_activities, args=args, kwargs=kwargs).start()

def simkl_sync_activities(force_update=False, init_callback=None, monitor=None):
	def _compare(section, keys):
		try:
			latest_section = latest.get(section) or {}
			cached_section = cached.get(section) or {}
			return any((latest_section.get(k) or '') != (cached_section.get(k) or '') for k in keys)
		except: return True
	if not get_setting('simkl_user', ''): return 'no account'
	try:
		check_databases()
		_flush_pending_writes()
		latest = simkl_get_activity()
		if not isinstance(latest, dict): return 'failed'
		cached = simkl_cache.reset_activity(latest) or simkl_cache.default_activities()
		if force_update or (latest.get('all') or '') != (cached.get('all') or ''):
			movie_status = _compare('movies', ('all', 'completed', 'plantowatch', 'removed_from_list'))
			tv_status = _compare('tv_shows', ('all', 'completed', 'watching', 'plantowatch', 'hold', 'dropped', 'removed_from_list'))
			if force_update or movie_status: simkl_indicators_movies()
			if force_update or tv_status: simkl_indicators_tv()
			if force_update or movie_status or tv_status:
				simkl_cache.clear_simkl_status_lists()
		return 'success'
	except Exception as e:
		logger('simkl_sync_activities error', str(e))
		return 'failed'

def simkl_rating(mediatype, tmdb_id):
	"""SIMKL's own rating for an item, for the info panel badge.

	Two hops (tmdb -> simkl id -> detail), so the result is cached for a week.
	Returns '' when SIMKL has no rating, which leaves the badge hidden.
	"""
	def _process(_):
		media_type = 'movie' if mediatype in ('movie', 'movies') else 'show'
		found = call_simkl('search/id', params={'tmdb': str(tmdb_id), 'type': media_type}, with_auth=False)
		if not isinstance(found, list) or not found: return ''
		ids = found[0].get('ids') or {}
		simkl_id = ids.get('simkl') or ids.get('simkl_id')
		if not simkl_id: return ''
		path = 'movies/%s' % simkl_id if media_type == 'movie' else 'tv/%s' % simkl_id
		detail = call_simkl(path, params={'extended': 'full'}, with_auth=False)
		try: return '%.1f' % float(detail['ratings']['simkl']['rating'])
		except: return ''
	try:
		string = 'simkl_rating_%s_%s' % (mediatype, tmdb_id)
		return cache_object(_process, string, None, expiration=168) or ''
	except: return ''

###############################################################################
# Account
###############################################################################

def simkl_account_settings():
	return call_simkl('users/settings', method='post')
