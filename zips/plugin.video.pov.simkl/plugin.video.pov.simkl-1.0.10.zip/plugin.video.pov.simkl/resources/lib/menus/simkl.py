from indexers import simkl_api, list_helper
from modules import kodi_utils
# logger = kodi_utils.logger

KODI_VERSION, ls = kodi_utils.get_kodi_version(), kodi_utils.local_string
build_url, make_listitem = kodi_utils.build_url, kodi_utils.make_listitem
fanart = kodi_utils.get_addoninfo('fanart')
default_icon = kodi_utils.media_path('simkl.png')

# SIMKL's five fixed statuses. There are no user-created lists.
STATUSES = (
	('plantowatch', 'Plan to Watch'),
	('watching', 'Watching'),
	('completed', 'Completed'),
	('hold', 'On Hold'),
	('dropped', 'Dropped')
)

def integrity_check():
	try:
		simkl_db = kodi_utils.translate_path(kodi_utils.simkl_db)
		with kodi_utils.database.connect(simkl_db) as dbcon:
			cur = dbcon.cursor()
			cur.execute("""PRAGMA integrity_check""")
			result = cur.fetchone()
		if 'ok' in result: status = 'passed'
		else: raise kodi_utils.database.Error(result)
		return status
	except kodi_utils.database.Error as e: status = str(e)
	try:
		with open(simkl_db, 'w') as _: pass
		from modules.cache import check_databases, clear_cache
		check_databases()
		clear_cache('simkl', silent=True)
		status = 'repaired'
	except Exception as e: kodi_utils.logger('simkl integrity error', '\n%s\n%s' % (status, e))
	return status

def simkl_account_info():
	from modules.utils import jsondate_to_datetime
	try:
		kodi_utils.show_busy_dialog()
		db_status = integrity_check()
		account_info = simkl_api.simkl_account_settings() or {}
		user = account_info.get('user') or {}
		account = account_info.get('account') or {}
		username = user.get('name') or kodi_utils.get_setting('simkl_user', '')
		timezone = account.get('timezone', '')
		account_type = account.get('type', '')
		try: joined = jsondate_to_datetime(user['joined_at']).astimezone().date()
		except: joined = ''
		# SIMKL exposes no stats endpoint (unlike Trakt's users/{}/stats), so
		# counts are derived from the synced status lists.
		counts = {}
		for status, label in STATUSES:
			for mediatype in ('movies', 'shows'):
				try: counts['%s_%s' % (mediatype, status)] = len(simkl_api._sync_list(mediatype, status))
				except: counts['%s_%s' % (mediatype, status)] = 0
		body = []
		append = body.append
		append('[B]Username:[/B] %s' % username)
		if timezone: append('[B]Timezone:[/B] %s' % timezone)
		if joined: append('[B]Joined:[/B] %s' % joined)
		if account_type: append('[B]Account:[/B] %s' % account_type)
		append('')
		append('[B]Movies[/B]')
		for status, label in STATUSES:
			append('  %s: [B]%s[/B]' % (label, counts.get('movies_%s' % status, 0)))
		append('')
		append('[B]TV Shows[/B]')
		for status, label in STATUSES:
			append('  %s: [B]%s[/B]' % (label, counts.get('shows_%s' % status, 0)))
		append('')
		append('[B]Cache Integrity:[/B] %s' % db_status.upper())
		kodi_utils.hide_busy_dialog()
		return kodi_utils.show_text(ls(32037).upper(), '\n\n'.join(body), font_size='large')
	except: kodi_utils.hide_busy_dialog()

class SimklManager(list_helper.BaseListManager):
	setting_key = 'simkl_user'
	icon_file = 'simkl.png'
	heading_id = 32198

	def _get_api(self):
		return simkl_api

	def get_default_choices(self):
		choices = [(status, label, '', self.icon) for status, label in STATUSES]
		choices.append(('mark_watched', 'Mark Watched / Unwatched', '', self.icon))
		return choices

	def handle_special_action(self, choice_id, choice_name):
		if choice_id == 'mark_watched':
			from caches.watched_cache import mark_as_watched_unwatched_movie, mark_as_watched_unwatched_tvshow
			params = {'tmdb_id': str(self.tmdb_id), 'mediatype': self.mediatype,
					  'action': 'mark_as_watched', 'title': self.params.get('title', '')}
			if self.mediatype in ('movie', 'movies'): return mark_as_watched_unwatched_movie(params)
			params['tvdb_id'] = self.params.get('tvdb_id', '0')
			return mark_as_watched_unwatched_tvshow(params)
		return False

	def check_item_exists(self, choice_id):
		list_items = self.api.simkl_fetch_collection_watchlist(choice_id, self.mediatype)
		return str(self.tmdb_id) in {str(i['media_ids']['tmdb']) for i in list_items}

	def execute_toggle(self, choice, action_add):
		status = choice[0]
		if action_add: success = self.api.simkl_add_to_list(status, self.mediatype, self.tmdb_id)
		else: success = self.api.simkl_remove_from_list(self.mediatype, self.tmdb_id)
		if not success: return kodi_utils.notification(32574)
		from caches.simkl_cache import clear_simkl_collection_watchlist_data
		clear_simkl_collection_watchlist_data(status, self.mediatype)
		kodi_utils.container_refresh()
		return success
