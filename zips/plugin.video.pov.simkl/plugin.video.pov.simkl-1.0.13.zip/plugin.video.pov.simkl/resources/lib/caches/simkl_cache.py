from modules.kodi_utils import simkl_db, database_connect
from modules.utils import chunks
# from modules.kodi_utils import logger

timeout = 20
SELECT = 'SELECT id FROM simkl_data'
DELETE = 'DELETE FROM simkl_data WHERE id = ?'
DELETE_LIKE = 'DELETE FROM simkl_data WHERE id LIKE ?'
WATCHED_INSERT = 'INSERT OR IGNORE INTO watched_status VALUES (?, ?, ?, ?, ?, ?)'
WATCHED_DELETE = 'DELETE FROM watched_status WHERE db_type = ?'
PROGRESS_INSERT = 'INSERT OR IGNORE INTO progress VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'
PROGRESS_DELETE = 'DELETE FROM progress WHERE db_type = ?'
BASE_DELETE = 'DELETE FROM %s'
SC_BASE_GET = 'SELECT data FROM simkl_data WHERE id = ?'
SC_BASE_SET = 'INSERT OR REPLACE INTO simkl_data (id, data) VALUES (?, ?)'
SC_BASE_DELETE = 'DELETE FROM simkl_data WHERE id = ?'
ID_MAP_GET = 'SELECT tmdb_id FROM simkl_id_map WHERE simkl_id = ? AND media_type = ?'
ID_MAP_SET = 'INSERT OR REPLACE INTO simkl_id_map (simkl_id, media_type, tmdb_id) VALUES (?, ?, ?)'

class SimklCache:
	batch_size = 1000
	def __init__(self):
		self._connect_database()
		self._set_PRAGMAS()

	def set_bulk_movie_watched(self, insert_list):
		self._delete(WATCHED_DELETE, ('movie',))
		for i in chunks(insert_list, self.batch_size):
			self._executemany(WATCHED_INSERT, i)

	def set_bulk_tvshow_watched(self, insert_list):
		self._delete(WATCHED_DELETE, ('episode',))
		for i in chunks(insert_list, self.batch_size):
			self._executemany(WATCHED_INSERT, i)

	def set_bulk_movie_progress(self, insert_list):
		self._delete(PROGRESS_DELETE, ('movie',))
		self._executemany(PROGRESS_INSERT, insert_list)

	def set_bulk_tvshow_progress(self, insert_list):
		self._delete(PROGRESS_DELETE, ('episode',))
		self._executemany(PROGRESS_INSERT, insert_list)

	def _executemany(self, command, insert_list):
		self.dbcur.executemany(command, insert_list)

	def _delete(self, command, args):
		self.dbcur.execute(command, args)
		self.dbcur.execute("""VACUUM""")

	def _connect_database(self):
		self.dbcon = database_connect(simkl_db, timeout=timeout, isolation_level=None)

	def _set_PRAGMAS(self):
		self.dbcur = self.dbcon.cursor()
		self.dbcur.execute("""PRAGMA synchronous = OFF""")
		self.dbcur.execute("""PRAGMA journal_mode = OFF""")
		self.dbcur.execute("""PRAGMA mmap_size = 268435456""")

# A status list is named several ways across the codebase -- the Watchlist menu
# calls it 'watchlist', the API calls it 'plantowatch', the Dropped menu calls
# itself 'droplist'. Collapse them so one list only ever has one cache key.
STATUS_ALIASES = {'watchlist': 'plantowatch', 'droplist': 'dropped'}

def status_list_key(status, mediatype):
	"""The single place a status-list cache key is built.

	Reader and invalidator used to compose this string independently: the
	Watchlist menu keyed on 'simkl_watchlist_shows' while the context menu's
	membership check keyed on 'simkl_plantowatch_tvshow'. Clearing one never
	touched the other, so a change made anywhere but the context menu left the
	membership set stale forever -- and since the menu decides Add vs Remove
	from that set, "Remove from Watchlist" silently performed a no-op add.
	"""
	status = STATUS_ALIASES.get(status, status)
	media = 'movies' if mediatype in ('movie', 'movies') else 'shows'
	return 'simkl_%s_%s' % (status, media)

def cache_simkl_object(function, string, url):
	dbcur = SimklCache().dbcur
	dbcur.execute(SC_BASE_GET, (string,))
	cached_data = dbcur.fetchone()
	if cached_data: return eval(cached_data[0])
	result = function(url)
	# Never persist an empty answer. This cache has no expiry, so a single
	# failed call would be remembered forever -- and membership checks read from
	# here, which turned "Remove from Watchlist" into a silent no-op add.
	if result: dbcur.execute(SC_BASE_SET, (string, repr(result)))
	return result

def get_id_map(simkl_id, media_type):
	# simkl_id -> tmdb_id never changes, so this is cached without expiry.
	try:
		dbcur = SimklCache().dbcur
		dbcur.execute(ID_MAP_GET, (str(simkl_id), media_type))
		result = dbcur.fetchone()
		return result[0] if result else None
	except: return None

def set_id_map(simkl_id, media_type, tmdb_id):
	try:
		dbcur = SimklCache().dbcur
		dbcur.execute(ID_MAP_SET, (str(simkl_id), media_type, str(tmdb_id)))
	except: pass

def set_id_map_bulk(insert_list):
	# insert_list: [(simkl_id, media_type, tmdb_id), ...]
	try:
		dbcur = SimklCache().dbcur
		for i in chunks(insert_list, 1000):
			dbcur.executemany(ID_MAP_SET, i)
	except: pass

PENDING_ADD = 'INSERT OR REPLACE INTO pending_writes (kind, action, mediatype, media_id, season, episode, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)'
PENDING_GET = 'SELECT kind, action, mediatype, media_id, season, episode FROM pending_writes ORDER BY created_at'
PENDING_DEL = 'DELETE FROM pending_writes WHERE kind = ? AND action = ? AND mediatype = ? AND media_id = ? AND season = ? AND episode = ?'

def queue_pending_write(kind, action, mediatype, media_id, season='', episode=''):
	"""Record a write that could not reach SIMKL, so the next sync can replay it."""
	from modules.utils import get_datetime
	try:
		dbcur = SimklCache().dbcur
		dbcur.execute(PENDING_ADD, (kind, action, mediatype, str(media_id),
									str(season or ''), str(episode or ''), str(get_datetime())))
	except: pass

def get_pending_writes():
	try:
		dbcur = SimklCache().dbcur
		dbcur.execute(PENDING_GET)
		return dbcur.fetchall() or []
	except: return []

def clear_pending_write(row):
	try:
		dbcur = SimklCache().dbcur
		dbcur.execute(PENDING_DEL, row)
	except: pass

def reset_activity(latest_activities):
	string = 'simkl_get_activity'
	cached_data = None
	try:
		dbcur = SimklCache().dbcur
		dbcur.execute(SC_BASE_GET, (string,))
		cached_data = dbcur.fetchone()
		if cached_data: cached_data = eval(cached_data[0])
		else: cached_data = default_activities()
		dbcur.execute(SC_BASE_SET, (string, repr(latest_activities)))
	except: pass
	return cached_data

def clear_simkl_collection_watchlist_data(list_type, mediatype):
	try:
		dbcur = SimklCache().dbcur
		dbcur.execute(DELETE, (status_list_key(list_type, mediatype),))
	except: pass

def clear_simkl_list_data(list_type):
	"""Clear a cache entry that is not a status list (e.g. hidden items)."""
	try:
		dbcur = SimklCache().dbcur
		dbcur.execute(DELETE, ('simkl_%s' % list_type,))
	except: pass

def clear_simkl_status_lists():
	"""Drop every cached status list, both media types."""
	try:
		dbcur = SimklCache().dbcur
		for status in ('plantowatch', 'watching', 'completed', 'hold', 'dropped'):
			for mediatype in ('movies', 'shows'):
				dbcur.execute(DELETE, (status_list_key(status, mediatype),))
	except: pass

def clear_simkl_recommendations(mediatype):
	string = 'simkl_recommendations_%s' % (mediatype)
	try:
		dbcur = SimklCache().dbcur
		dbcur.execute(DELETE, (string,))
	except: pass

def clear_all_simkl_cache_data(refresh=True):
	try:
		dbcur = SimklCache().dbcur
		# simkl_id_map is deliberately preserved -- the mapping is immutable and
		# expensive to rebuild, and it holds no user state.
		for table in ('simkl_data', 'progress', 'watched_status'):
			dbcur.execute(BASE_DELETE % table)
		dbcur.execute("""VACUUM""")
		if not refresh: return True
		from indexers.simkl_api import simkl_sync_activities_thread
		simkl_sync_activities_thread()
		return True
	except: return False

def default_activities():
	# Mirrors the verified shape of GET /sync/activities. Null means "never".
	def _media(extra=()):
		base = {'all': '', 'rated_at': '', 'playback': '', 'plantowatch': '',
				'completed': '', 'dropped': '', 'removed_from_list': ''}
		base.update(dict.fromkeys(extra, ''))
		return base
	return {
			'all': '',
			'settings': {'all': ''},
			'tv_shows': _media(('watching', 'hold')),
			'anime': _media(('watching', 'hold')),
			'movies': _media()
			}
