"""Seed FENtastic's menus and widgets for POV SIMKL on a fresh profile.

Added by the POV SIMKL repo; not part of upstream FENtastic.

The Apple TV periodically clears Kodi's add-ons. The widget configuration itself
lives in userdata (cpath_cache.db) and normally survives, but a genuinely fresh
profile comes up with no menus at all. This seeds a known-good set so the home
screen works immediately.

Deliberately conservative:
  * only runs when the custom_paths table is EMPTY -- it never overwrites a
    configuration made on the device
  * records a marker afterwards so it does not retry on every start
  * any failure is swallowed; a broken seed must never stop the helper's service
"""
import json
import os

import xbmc
import xbmcaddon
import xbmcvfs

ADDON = xbmcaddon.Addon('script.fentastic.helper')
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
DB = os.path.join(PROFILE, 'cpath_cache.db')
SEED = os.path.join(
    xbmcvfs.translatePath(ADDON.getAddonInfo('path')),
    'resources', 'lib', 'modules', 'simkl_widget_seed.json'
)
MARKER = os.path.join(PROFILE, '.simkl_seeded')


def _log(msg):
    xbmc.log('###FENtastic/simkl_seed: %s' % msg, 1)


def seed_if_empty():
    try:
        if os.path.exists(MARKER):
            return False
        if not os.path.exists(SEED):
            _log('no seed file, skipping')
            return False

        import sqlite3
        if not os.path.exists(PROFILE):
            os.makedirs(PROFILE)

        con = sqlite3.connect(DB, timeout=20)
        con.execute(
            'CREATE TABLE IF NOT EXISTS custom_paths '
            '(cpath_setting text unique, cpath_path text, cpath_header text, '
            'cpath_type text, cpath_label text)'
        )
        existing = con.execute('SELECT COUNT(*) FROM custom_paths').fetchone()[0]
        if existing:
            # Already configured on this device -- leave it completely alone.
            _log('custom_paths has %d rows, not seeding' % existing)
            con.close()
            _mark()
            return False

        with open(SEED) as fh:
            rows = json.load(fh)['rows']
        con.executemany(
            'INSERT OR REPLACE INTO custom_paths VALUES (?, ?, ?, ?, ?)',
            [(r['cpath_setting'], r['cpath_path'], r['cpath_header'],
              r['cpath_type'], r['cpath_label']) for r in rows]
        )
        con.commit()
        con.close()
        _log('seeded %d menu/widget rows' % len(rows))
        _mark()

        # Generate the skin XMLs so the widgets render without the user having
        # to run Skin settings > Main menu items > Remake menus and widgets.
        try:
            from modules.cpath_maker import remake_all_cpaths
            remake_all_cpaths(silent=True)
            _log('remade menus and widgets')
        except Exception as exc:
            _log('remake failed (%s); run Remake menus and widgets manually' % exc)
        return True
    except Exception as exc:
        _log('seed failed: %s' % exc)
        return False


def _mark():
    try:
        with open(MARKER, 'w') as fh:
            fh.write('seeded')
    except Exception:
        pass
