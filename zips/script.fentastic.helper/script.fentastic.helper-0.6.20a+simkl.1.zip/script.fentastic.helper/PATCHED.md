# Patched build

FENtastic Helper by **Tikipeter** and **Ivar Brandt**, GPL-2.0.
Unmodified except for a seed that installs default POV SIMKL menus and
widgets on a profile that has none, then regenerates the skin XMLs.

It only runs when `custom_paths` is empty, so a configuration made on the
device is never overwritten.

Regenerate with `tools/patch_fentastic_helper.py` after any upstream update.
